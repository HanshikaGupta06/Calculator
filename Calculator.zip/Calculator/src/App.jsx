import React from 'react'
import Calci from './components/Calci'

const App = () => {

  return (
    <div className=' bg-purple-200 flex-col justify-center flex w-full items-center p-5'>
      <h1 className='font-bold text-3xl'>Hg's CALCULATOR!</h1>
      <Calci />
    </div>
  )
}

export default App