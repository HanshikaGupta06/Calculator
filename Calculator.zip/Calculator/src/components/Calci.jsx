import React, { useState } from 'react'
import { CircleArrowLeft } from 'lucide-react'

const Calci = () => {

    const [val, setVal] = useState('')
    const handleClick = (value) => {
        setVal((prev) => prev + value)
    }

    const clear = () => (setVal(''))

    const evaluate = () => {
        try {
            setVal(eval(val).toString())
        } catch (error) {
            setVal("error")
        }
    }

    const arrow = () => (
        setVal((prev) => prev.slice(0, -1))
    )
    const buttons = [
        "7", "8", "9", "/",
        "4", "5", "6", "*",
        "1", "2", "3", "-",
        "0", ".", "=", "+",
    ]
    return (
        <div className='bg-gray-800 border-2 rounded-lg w-100 p-7 mt-5'>
            <div className='border-2 rounded-lg bg-gray-400 p-3 text-2xl text-right mb-3'>{val || '0'}</div>
            <div className='grid grid-cols-4 gap-3'>
                {buttons.map((but) => (
                    <button
                        className='rounded-lg p-3 m-2 bg-gray-400 hover:scale-110 transition-all duration-400 text-white font-bold text-xl cursor-pointer'
                        key={but}
                        onClick={() => (but === '=' ? evaluate() :
                            handleClick(but)

                        )}
                    >
                        {but}
                    </button>
                ))}
                <button
                    className='border-1 bg-red-400 font-bold rounded-lg col-span-2 p-3'
                    onClick={() => (clear())}
                > CLEAR

                </button>
                <button
                    onClick={() => (arrow())}
                    className='border-1 bg-blue-400 font-bold rounded-lg col-span-2 p-3 pl-17'>
                    <CircleArrowLeft />

                </button>
            </div>
        </div>
    )
}

export default Calci