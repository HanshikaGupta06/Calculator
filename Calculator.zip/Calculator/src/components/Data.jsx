import React from 'react'

const Data = (props) => {
    const name = props.name;
    const age = props.age;
  return (
    <div>
        <h1>{name}</h1>
        <h1>{age}</h1>
    </div>
  )
}

export default Data